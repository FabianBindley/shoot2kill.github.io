// the Game object used by the phaser.io library
var stateActions = { preload: preload, create: create, update: update };

// Phaser parameters:
// - game width
// - game height
// - renderer (go for Phaser.AUTO)
// - element where the game will be drawn ('game')
// - actions on the game state (or null for nothing)
var game = new Phaser.Game(1024, 450, Phaser.AUTO, 'game', stateActions);

//Variables!

var score=0;
var labelscore;
var player;
var ball=[];
var doge=[];
var timerloop = 1.75 * Phaser.Timer.SECOND;



/*
 * Loads all resources for the game and gives them names.
 */
function preload() {
  game.load.image("sprite", "../assets/sprite.png");
  game.load.image("background","../assets/background.png");
  game.load.image("ball","../assets/ball.png");
  game.load.image("doge","../assets/doge.png");

}

/* * Initialises the game. This function is only called once.
 */
function create() {
  //start the phaser ARCADE physics engine
  game.physics.startSystem(Phaser.Physics.ARCADE);


  //background
  game.add.image(0, 0, "background");
  game.stage.setBackgroundColor("#ffffff");

  //Text
  game.add.text(300,20, "Welcome to Dogeball", {font: "20px Arial"});

  //add the sprite
  player = game.add.sprite(500, 200, "sprite");
  game.physics.arcade.enable(player);
  //Moving the player

      game.input.keyboard.addKey(Phaser.Keyboard.RIGHT)
                        .onDown.add(moveRight);

      game.input.keyboard.addKey(Phaser.Keyboard.RIGHT)
                        .onUp.add(stopRight);

      game.input.keyboard.addKey(Phaser.Keyboard.LEFT)
                        .onDown.add(moveLeft);

      game.input.keyboard.addKey(Phaser.Keyboard.LEFT)
                        .onUp.add(stopLeft);

      game.input.keyboard.addKey(Phaser.Keyboard.UP)
                        .onDown.add(moveUp);

      game.input.keyboard.addKey(Phaser.Keyboard.UP)
                        .onUp.add(stopUp);

      game.input.keyboard.addKey(Phaser.Keyboard.DOWN)
                        .onDown.add(moveDown);

      game.input.keyboard.addKey(Phaser.Keyboard.DOWN)
                        .onUp.add(stopDown);

      game.input.keyboard.addKey(Phaser.Keyboard.D)
                        .onDown.add(moveRight);

      game.input.keyboard.addKey(Phaser.Keyboard.A)
                        .onDown.add(moveLeft);

      game.input.keyboard.addKey(Phaser.Keyboard.W)
                        .onDown.add(moveUp);

      game.input.keyboard.addKey(Phaser.Keyboard.S)
                        .onDown.add(moveDown);

      labelscore = game.add.text(20,20,"0");

      var generateInterval = 3 * Phaser.Timer.SECOND;
          game.time.events.loop(
            generateInterval,
            console.log("hi")
          );


}
/*
 * This function updates the scene. It is called for every new frame.
 */
function update() {

}
//Lots of Movement Functions
function moveUp(){
  player.body.velocity.y = -200;
}

function stopUp(){
  player.body.velocity.y=0;
}

function moveDown(){
  player.body.velocity.y=200;
}
function stopDown(){
  player.body.velocity.y=0;
}

function moveLeft(){
  player.body.velocity.x = -200;
}
function stopLeft(){
  player.body.velocity.x=0;
}

function moveRight(){
  player.body.velocity.x = 200;
}
function stopRight(){
  player.body.velocity.x=0;
}

function changeScore() {
score = score + 1;
labelScore.setText(score.toString());
}

function generateBall(){
  var object = game.add.sprite(200, 200, "ball");
  ball.push(object);
  game.physics.arcade.enable(object);
  object.body.velocity.x =100;
  object.body.velocity.y =- game.rnd.integerInRange(0, 100);

}

function generateDoge(){
  var object = game.add.sprite(100, 100, "doge");
  doge.push(object);
  game.physics.arcade.enable(object);
  object.body.velocity.x =-100;
  object.body.velocity.y =- game.rnd.integerInrange(60,120);

}

function generate(){

  if (score > 11){
    var diceRoll = game.rnd.IntegerInRange(1,3);
      if(diceRoll==1){
        generateBall();
      } else if(diceRoll==2){
        generateDoge();
      }else{
      }

    }





}
